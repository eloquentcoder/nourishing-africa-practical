<?php

namespace App\Exceptions;

use Exception;

class CompanyThresholdExceededException extends Exception
{
    //
}
