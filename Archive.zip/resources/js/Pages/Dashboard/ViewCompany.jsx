import { Head, Link, useForm, usePage } from '@inertiajs/inertia-react';
import PrimaryButton from '../../Components/PrimaryButton';
import DashboardLayout from "../../Layouts/Dashboard";


export default function ViewCompany({ company }) {
    return (
        <DashboardLayout>
            <Head title="View Company" />

            <div className="px-5 md:px-[5rem] py-10">
                <div>
                    <div className="flex justify-between">
                        <div className="font-bold text-2xl mb-3">{company.name} Company</div>
                        <div className="flex-end">
                            <Link href={`/companies/${company.id}/edit`}>
                                <PrimaryButton text="Edit" />
                            </Link>
                        </div>
                    </div>
                    <div className="card card-compact w-full bg-base-100 shadow-xl mt-4">
                        <div className="card-body flex flex-row">
                            <li className="flex flex-col space-y-5 justify-between p-5 w-1/2">
                                <h1 className="font-bold text-lg">Company Name</h1>
                                <h1 className="font-bold text-lg">Company Email</h1>
                                <h1 className="font-bold text-lg">Company Location</h1>
                            </li>

                            <li className="flex flex-col space-y-5 justify-between p-5 w-1/2">
                                <h1 className="font-bold text-xs">{company.name}</h1>
                                <h1 className="font-bold text-xs">{company.email}</h1>
                                <h1 className="font-bold text-xs">{company.location}</h1>
                            </li>
                            {/* <li className="flex items-center justify-between">
                                    <p>Facebook</p>
                                    <div className="flex space-x-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="w-3 h-3">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
                                        </svg>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="w-3 h-3">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        </svg>
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="w-3 h-3">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9.75L14.25 12m0 0l2.25 2.25M14.25 12l2.25-2.25M14.25 12L12 14.25m-2.58 4.92l-6.375-6.375a1.125 1.125 0 010-1.59L9.42 4.83c.211-.211.498-.33.796-.33H19.5a2.25 2.25 0 012.25 2.25v10.5a2.25 2.25 0 01-2.25 2.25h-9.284c-.298 0-.585-.119-.796-.33z" />
                                        </svg>

                                    </div>
                                </li> */}
                        </div>
                    </div>
                </div>
            </div>


        </DashboardLayout>
    );
}